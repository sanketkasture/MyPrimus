import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { UserDataService } from '../services/user-data.service';
import { throwError } from 'rxjs';
import { HttpHeaders } from '@angular/common/http';

@Component({
  selector: 'app-admin-page',
  templateUrl: './admin-page.component.html',
  styleUrls: ['./admin-page.component.css'],
})
export class AdminPageComponent implements OnInit {
  status: 'initial' | 'uploading' | 'success' | 'fail' = 'initial';
  file: File | null = null;

  employeeForm!: FormGroup;
  // customerForm!: FormGroup;
  clientForm!: FormGroup;
  newsArticleForm!: FormGroup;
  eventForm!: FormGroup;
  http: any;
  EventUrl: any;
  file_data: any;
  constructor(private userData: UserDataService) {}

  check: any;

  ngOnInit(): void {
    (this.employeeForm = new FormGroup({
      id: new FormControl('', [Validators.required]),
      firstName: new FormControl('', [Validators.required]),
      middleName: new FormControl('', [Validators.required]),
      lastName: new FormControl('', [Validators.required]),
      birthDate: new FormControl('', [Validators.required]),
      designation: new FormControl('', [Validators.required]),
      joiningDate: new FormControl('', [Validators.required]),
      address: new FormControl('', [Validators.required]),
      contact: new FormControl('', [Validators.required]),
      email: new FormControl('', [Validators.required, Validators.email]),
      photo: new FormControl('', [Validators.required]),
    })),
      (this.clientForm = new FormGroup({
        clientId: new FormControl('', [Validators.required]),
        empID: new FormControl('', [Validators.required]),
        empName: new FormControl('', [Validators.required]),
        empDesignation: new FormControl('', [Validators.required]),
        teamName: new FormControl('', [Validators.required]),
        date: new FormControl('', [Validators.required]),
        clientLogo: new FormControl('', [Validators.required]),
        //description: new FormControl('', [Validators.required])
        // clientAppre: new FormControl('', [Validators.required]),
        // clientCity: new FormControl('', [Validators.required]),
      })),
      (this.newsArticleForm = new FormGroup({
        id: new FormControl('', [Validators.required]),
        autherName: new FormControl('', [Validators.required]),
        date: new FormControl('', [Validators.required]),
        description: new FormControl('', [Validators.required]),
        articleImg: new FormControl('', [Validators.required]),
      })),
      (this.eventForm = new FormGroup({
        id: new FormControl('', [Validators.required]),
        category: new FormControl('', [Validators.required]),
        date: new FormControl('', [Validators.required]),
        image: new FormControl('', [Validators.required]),
      }));
  }

  // New Employee Form
  get idField(): any {
    return this.employeeForm.get('id');
  }

  get fNameField(): any {
    return this.employeeForm.get('firstName');
  }

  get mNameField(): any {
    return this.employeeForm.get('middleName');
  }

  get lNameField(): any {
    return this.employeeForm.get('lastName');
  }

  get bDateField(): any {
    return this.employeeForm.get('birthDate');
  }

  get jDateField(): any {
    return this.employeeForm.get('joiningDate');
  }

  get desigField(): any {
    return this.employeeForm.get('designation');
  }

  get empAddField(): any {
    return this.employeeForm.get('address');
  }

  get empPhnField(): any {
    return this.employeeForm.get('contact');
  }

  get emailField(): any {
    return this.employeeForm.get('email');
  }

  get empPhotoField(): any {
    return this.employeeForm.get('photo');
  }
  employeeFormSubmit(): void {
    this.check = this.employeeForm.value;
    this.userData.SaveEmployeeData(this.check).subscribe((result) => {
      console.log(result);
    });
    // Call Api
  }

  clientFormSubmit(): void {
    // console.log(this.clientForm.value)
    this.check = this.clientForm.value;
    this.userData.SaveCustAppData(this.check).subscribe((result) => {
      console.log(result);
    });
  }
  // Client Form
  get clientIdField(): any {
    return this.clientForm.get('clientId');
  }
  get employeeIdField(): any {
    return this.clientForm.get('empID');
  }
  get employeeNameField(): any {
    return this.clientForm.get('empName');
  }
  get employeeDesignField(): any {
    return this.clientForm.get('empDesignation');
  }
  get teamNameField(): any {
    return this.clientForm.get('teamName');
  }
  get appDateField(): any {
    return this.clientForm.get('date');
  }
  get clientLogoField(): any {
    return this.clientForm.get('clientLogo');
  }
  // get clientAppField(): any {
  //   return this.clientForm.get('description');
  // }
  get clientCityField(): any {
    return this.clientForm.get('clientCity');
  }

  // News Form
  get nidField(): any {
    return this.newsArticleForm.get('id');
  }

  get autherNameField(): any {
    return this.newsArticleForm.get('autherName');
  }

  get articleDateField(): any {
    return this.newsArticleForm.get('date');
  }

  get articleImgField(): any {
    return this.newsArticleForm.get('articleImg');
  }

  get articleDescField(): any {
    return this.newsArticleForm.get('description');
  }

  newsArticleFormSubmit(): void {
    //console.log(this.newsArticleForm.value);
    this.check = this.newsArticleForm.value;
    this.userData.SaveLatestNewsData(this.check).subscribe((result) => {
      console.log(result);
    });
    // Call Api
  }

  // Event Form
  get eidField(): any {
    return this.eventForm.get('id');
  }

  get eCategoryField(): any {
    return this.eventForm.get('category');
  }

  get eDateField(): any {
    return this.eventForm.get('date');
  }

  get eImageField(): any {
    return this.eventForm.get('image');
  }

  onFileSelected(event: any) {
    var files = event.target.files;
    this.file_data = files;
    console.log('Please choose any file...', files);
    if (files.length == 0) {
      alert('Please choose any file...');
      return;
    }
    console.log('file data is ', files);
    var filename = files[0].name;

    var extension = filename.substring(filename.lastIndexOf('.')).toUpperCase();
    if (extension == '.PNG' || extension == '.JPEG') {
      this.eventForm.patchValue({
        ImageUpload: files[0],
        image: files[0].name,
      });
    } else {
      // this.commonService.showError("Please select a valid Image file Ex.(.png,.jpeg).");
    }
  }

  async uploadImage() {
    const formData = new FormData();
    for (var i = 0; i < this.file_data.length; i++) {
      console.log(this.file_data[i]);
      formData.append('file', this.file_data[i]);
    }
    formData.append('data', this.eventForm.value);
   
    let data = { data: formData};
    console.log('DATA is:', data);

    this.userData.SaveEventData(data).subscribe({
      next: async (result: any) => {
        if (result) {
          console.log('Result:', result);
        }
      },
      error: (error: any) => {},
    });
  }

  //  onUpload() {
  //   if (this.file) {
  //     const reader = new FileReader();
  //     reader.onloadend = () => {
  //       const base64String = reader.result;
  //       const formData = new FormData();

  //     //   formData.append('file', this.eventForm.value.image);
  //     //   formData.append('id', this.eventForm.value.id);
  //     //   formData.append('category', this.eventForm.value.category);
  //     //   formData.append('date', this.eventForm.value.date);
  //     //   // formData.append('formControl4', this.eventForm.value.formControl4);
  //     //   let headers = new HttpHeaders({ 'Content-Type': 'application/json' });
  //     //   const upload$ = this.http.post(this.EventUrl, formData, {
  //     //     headers: headers,
  //     //   });
  //     //   this.status = 'uploading';
  //     //   upload$.subscribe({
  //     //     next: () => {
  //     //       this.status = 'success';
  //     //     },
  //     //     error: (error: any) => {
  //     //       this.status = 'fail';
  //     //       return throwError(() => error);
  //     //     },
  //     //   });
  //     // };
  //     // reader.readAsDataURL(this.file);
  //   }
  // }
  // }

  // eventFormSubmit(): void {

  //   const formData = new FormData();

  //   let data ={file: this.eventForm.value.image, data:this.eventForm.value}
  //   console.log("DATA is:",data);

  //   const upload$ = this.http.post(this.EventUrl, data, {
  //       });
  //       upload$.subscribe({
  //             next: () => {
  //               this.status = 'success';
  //             },
  //             error: (error: any) => {
  //               this.status = 'fail';
  //               return throwError(() => error);
  //             },
  //           });

  //   // console.log(this.eventForm.value);

  //   this.check = this.eventForm.value;
  //   this.userData.SaveEventData(this.check).subscribe((result) => {
  //     console.log(result);
  //   });
  //   // Call Api
  // }
}
