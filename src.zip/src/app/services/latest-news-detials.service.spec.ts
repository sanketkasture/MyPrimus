import { TestBed } from '@angular/core/testing';

import { LatestNewsDetialsService } from './latest-news-detials.service';

describe('LatestNewsDetialsService', () => {
  let service: LatestNewsDetialsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(LatestNewsDetialsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
