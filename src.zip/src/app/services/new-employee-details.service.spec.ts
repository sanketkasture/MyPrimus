import { TestBed } from '@angular/core/testing';

import { NewEmployeeDetailsService } from './new-employee-details.service';

describe('NewEmployeeDetailsService', () => {
  let service: NewEmployeeDetailsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(NewEmployeeDetailsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
