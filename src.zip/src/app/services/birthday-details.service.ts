import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class BirthdayDetailsService {

  constructor() { }

  EmployeeDetails = [
    {
      empid: 1,
      empName:"John Doe",
      empProfile:"UI Designer",
      empBdate:"15-Nov-1995",
      empPhoto:"./assets/emp1.jpg"
    },
    {
      empid: 2,
      empName:"Steve Smith",
      empProfile:"Web Devloper",
      empBdate:"25-Jan-1998",
      empPhoto:"./assets/emp2.jpg"
    },
    {
      empid: 3,
      empName:"Ann Chovey",
      empProfile:"Accountant",
      empBdate:"1-May-1989",
      empPhoto:"./assets/emp3.jpg"
    },
    {
      empid: 4,
      empName:"Marsha Mellow",
      empProfile:"Marketing Manager",
      empBdate:"6-Sept-1985",
      empPhoto:"./assets/emp4.jpg"
    },
    {
      empid: 5,
      empName:"Olive Yew",
      empProfile:"Quality Control",
      empBdate:"21-Feb-2000",
      empPhoto:"./assets/emp1.jpg"
    }
  ]
}
