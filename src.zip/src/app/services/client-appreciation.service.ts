import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ClientAppreciationService {

  constructor() { }

  ClientFeedback = [
    {
      clientId: 1,
      clientName:"Rahul Kulkarni",
      clientProfile:"Manager - Reliable Pvt. Ltd.",
      teamName:"Website team",
      desc:"Lorem ipsum is simply free text used by copytyping refreshing. Neque porro est qui dolorem ipsum quia quaed inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Aelltes port lacus quis enim var sed efficitur turpis gilla sed sit amet finibus eros.",
      feedbackDate:"10 Nov, 2023",
      clientLogo:"./assets/client-logo1.png",
      clientTropy:"./assets/trophy.png"
    },

    {
      clientId: 2,
      clientName:"Mahesh Manjarekar",
      clientProfile:"Manager - Umicore Pvt. Ltd.",
      teamName:"Sales team",
      desc:"Lorem ipsum is simply free text used by copytyping refreshing. Neque porro est qui dolorem ipsum quia quaed inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Aelltes port lacus quis enim var sed efficitur turpis gilla sed sit amet finibus eros.",
      feedbackDate:"10 Nov, 2023",
      clientLogo:"./assets/client-logo2.png",
      clientTropy:"./assets/trophy.png"
    }

    
    
  ]
}
