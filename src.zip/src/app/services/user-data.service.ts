import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UserDataService {
  // Employee Data
  
  url = "http://115.160.216.115:5003/api/Employee";
  custAppUrl = "http://115.160.216.115:5003/api/Customer_Appreciation";
  newsUrl = "http://115.160.216.115:5003/api/News_Articles";
  EventUrl = "http://115.160.216.115:5003/api/Events";
  loginUrl = "http://115.160.216.115:5003/api/User"

  constructor(private http:HttpClient) { }

loginUser(){
  return this.http.get(this.loginUrl);
}
SaveLoginUserData(data:any){
  console.log(data);
  return this.http.post(this.loginUrl, data);
}


  users(){
    return this.http.get(this.url);
  }
  SaveEmployeeData(data:any){
    console.log(data);
    return this.http.post(this.url, data);
  }

  custApp(){
    return this.http.get(this.custAppUrl)
  }
  SaveCustAppData(data:any){
    console.log(data);
    return this.http.post(this.custAppUrl, data);
  }


  latestNews(){
    return this.http.get(this.newsUrl)
  }
  SaveLatestNewsData(data:any){
    console.log(data);
    return this.http.post(this.newsUrl, data);
  }


 
  evtDetails(){
    return this.http.get(this.EventUrl);
  }
  SaveEventData(data:any){
    console.log(data);
    return this.http.post(this.EventUrl, data);
  } 
  

}


