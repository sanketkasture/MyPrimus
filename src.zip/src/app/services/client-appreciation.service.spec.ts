import { TestBed } from '@angular/core/testing';

import { ClientAppreciationService } from './client-appreciation.service';

describe('ClientAppreciationService', () => {
  let service: ClientAppreciationService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ClientAppreciationService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
