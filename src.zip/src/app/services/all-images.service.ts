import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AllImagesService {

 
  constructor() { }

  AllImageDetails = [
    {
      imgid: 1,
      imgcategory:"party",
      imgpath:"./assets/b-party1.jpg"
    },
    {
      imgid: 2,
      imgcategory:"traditional",
      imgpath:"./assets/trad1.jpg"
    },
    {
      imgid: 3,
      imgcategory:"traditional",
      imgpath:"./assets/holi1.jpg"
    },
    {
      imgid: 4,
      imgcategory:"event",
      imgpath:"./assets/event1.jpg"
    },
    {
      imgid: 5,
      imgcategory:"traditional",
      imgpath:"./assets/trad2.jpg"
    },
    {
      imgid: 6,
      imgcategory:"event",
      imgpath:"./assets/event2.jpg"
    },
    {
      imgid: 7,
      imgcategory:"party",
      imgpath:"./assets/b-party2.jpg"
    },
    {
      imgid: 8,
      imgcategory:"traditional",
      imgpath:"./assets/holi2.jpg"
    },
    {
      imgid: 9,
      imgcategory:"event",
      imgpath:"./assets/event3.jpg"
    },
    {
      imgid: 10,
      imgcategory:"party",
      imgpath:"./assets/b-party3.jpg"
    },
    {
      imgid: 11,
      imgcategory:"traditional",
      imgpath:"./assets/trad3.jpg"
    },
    {
      imgid: 12,
      imgcategory:"event",
      imgpath:"./assets/event4.jpg"
    },
  ]
}
