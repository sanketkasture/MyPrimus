import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class NewEmployeeDetailsService {

  constructor() { }

  newEmployeeDetails = [
    {
      empid: 1,
      empName:"John Doe",
      empProfile:"UI Designer",
      empBdate:"15-Nov-1995",
      empPhoto:"./assets/new-member-1.png"
    },
    {
      empid: 2,
      empName:"Steve Smith",
      empProfile:"Web Devloper",
      empBdate:"25-Jan-1998",
      empPhoto:"./assets/new-member-2.png"
    },
    {
      empid: 3,
      empName:"Ann Chovey",
      empProfile:"Accountant",
      empBdate:"1-May-1989",
      empPhoto:"./assets/new-member-3.png"
    },
    {
      empid: 4,
      empName:"Marsha Mellow",
      empProfile:"Marketing Manager",
      empBdate:"6-Sept-1985",
      empPhoto:"./assets/new-member-4.png"
    },
    {
      empid: 5,
      empName:"Olive Yew",
      empProfile:"Quality Control",
      empBdate:"21-Feb-2000",
      empPhoto:"./assets/new-member-5.png"
    },
    {
      empid: 6,
      empName:"Aida Bugg",
      empProfile:"UX Designer",
      empBdate:"15-Nov-1996",
      empPhoto:"./assets/new-member.png"
    }
  ]
}
