import { Component, OnInit } from '@angular/core';

// import { LatestNewsDetialsService } from 'src/app/services/latest-news-detials.service';
// import { ClientAppreciationService } from '../services/client-appreciation.service';
//import { AllImagesService } from '../services/all-images.service';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserDataService } from '../services/user-data.service'


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  tabs:string [] = ['All', 'Traditional','Sport','Birthdays','Events'];
  activatedTabIndex: number = 0;
  check : any;

  loginForm!: FormGroup;
  employeesData:any;
  latestNewsData:any;
  custAppData:any;
  EventGallery:any;

  constructor(private router: Router, private userData:UserDataService){
      userData.users().subscribe((data)=>{
        console.log("data", data);
        this.employeesData = data;
      });

      userData.latestNews().subscribe((data1)=>{
        this.latestNewsData = data1;
      });

      userData.custApp().subscribe((data2)=>{
        this.custAppData = data2;
      })

      userData.evtDetails().subscribe((data3)=>{
        this.EventGallery = data3;
      })
    }

  

  // newsData:any;
  // clientApp:any;
  //allImages:any;

  ngOnInit(): void {
    // this.newsData = this.service2.LatestNews;
    // this.clientApp = this.service3.ClientFeedback;
    //this.allImages = this.service4.AllImageDetails;

    this.loginForm = new FormGroup({
      EmpID: new FormControl('', [Validators.required] ),
      Password: new FormControl('', [Validators.required] )
    })
    
  }

  get emailField(): any {
    return this.loginForm.get('EmpID');
  }
  get passwordField(): any {
    return this.loginForm.get('Password');
  }
  loginFormSubmit(): void {
    // console.log(this.loginForm.value);
    // this.router.navigate(['/admin']);

    this.check = this.loginForm.value;
    this.userData.SaveLoginUserData(this.check).subscribe((result)=>{
    console.log(result);
    this.router.navigate(['/admin']);
    });
    // Call Api
  }

  tabChange(tabIndex:number){
    this.activatedTabIndex = tabIndex;
  }  
  
}
